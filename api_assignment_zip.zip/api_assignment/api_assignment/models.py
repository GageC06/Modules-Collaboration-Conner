from flask_sqlachemy import SQLAlchemy

db = SQLAlchemy()

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_name = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    publisher = db.Column(db.String(100), nullable=False)


    def as_dict(self):
        return{
            "id": self.id,
            "book": self.book_name,
            "author": self.author,
            "publisher": self.publisher
        }

